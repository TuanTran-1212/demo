import React, { useEffect, useState } from "react";
import { View, Text, Image, ScrollView, StyleSheet, TouchableOpacity } from "react-native";
import { useRoute, useNavigation } from "@react-navigation/native";
import Ionicons from "@react-native-vector-icons/ionicons";
import { getMealDetail } from "../services/api";

const DishDetailScreen = () => {
  const route = useRoute();
  const navigation = useNavigation();

  const { recipeID } = route.params as any;
  // console.log('Received recipeID:', recipeID);

  const [recipe, setRecipe] = useState<any>(null);

  useEffect(() => {
    const fetchDetail = async () => {
      // console.log('Fetching detail for ID:', recipeID);
      const recipeDetail = await getMealDetail(recipeID);
      // console.log('API Response:', recipeDetail);
      setRecipe(recipeDetail);
    };

    fetchDetail();
  }, []);

  if (!recipe) return <Text>Loading...</Text>;

  return (
    <ScrollView style={styles.container}>

      <TouchableOpacity
        style={styles.back}
        onPress={() => navigation.goBack()}
      >
        <Ionicons name="arrow-back" size={24} />
      </TouchableOpacity>

      <Image source={{ uri: recipe.strMealThumb }} style={styles.image} />

      <View style={styles.content}>
        <Text style={styles.title}>{recipe.strMeal}</Text>

        <Text style={styles.meta}>
          {recipe.strCategory} • {recipe.strArea}
        </Text>

        <Text style={styles.section}>Instructions</Text>
        <Text style={styles.text}>{recipe.strInstructions}</Text>
      </View>

    </ScrollView>
  );
};
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff" },

  back: {
    position: "absolute",
    top: 50,
    left: 20,
    zIndex: 1,
    backgroundColor: "#fff",
    padding: 10,
    borderRadius: 20
  },

  image: {
    width: "100%",
    height: 300
  },

  content: {
    padding: 20
  },

  title: {
    fontSize: 26,
    fontWeight: "bold"
  },

  meta: {
    color: "#666",
    marginVertical: 8
  },

  section: {
    fontSize: 20,
    fontWeight: "bold",
    marginTop: 20
  },

  text: {
    marginTop: 10,
    lineHeight: 22
  }
});

export default DishDetailScreen;
